import app from "./app";

app.listen("3333", () => {
  console.log("API started on port 3333!");
});
